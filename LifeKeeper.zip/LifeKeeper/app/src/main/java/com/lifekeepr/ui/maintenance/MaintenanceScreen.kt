package com.lifekeepr.ui.maintenance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lifekeepr.data.local.entity.HomeMaintenanceItem
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

enum class MaintenanceStatus { OVERDUE, SOON, NORMAL, UNRECORDED }

fun HomeMaintenanceItem.status(): MaintenanceStatus {
    val last = lastDoneAt ?: return MaintenanceStatus.UNRECORDED
    val elapsed = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - last)
    return when {
        elapsed >= cycleDays -> MaintenanceStatus.OVERDUE
        elapsed >= cycleDays * 0.85 -> MaintenanceStatus.SOON
        else -> MaintenanceStatus.NORMAL
    }
}

@Composable
fun MaintenanceScreen(viewModel: MaintenanceViewModel = hiltViewModel()) {
    val items by viewModel.items.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }

    val overdueItems = items.filter { it.status() == MaintenanceStatus.OVERDUE || it.status() == MaintenanceStatus.UNRECORDED }
    val soonItems = items.filter { it.status() == MaintenanceStatus.SOON }
    val normalItems = items.filter { it.status() == MaintenanceStatus.NORMAL }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("집 관리", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "지남 ${overdueItems.size} · 곧 필요 ${soonItems.size} · 정상 ${normalItems.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("항목 추가") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (overdueItems.isNotEmpty()) {
                item {
                    Text(
                        "⚠️ 지남 / 미기록",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFE53935),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                items(overdueItems, key = { it.id }) { item ->
                    MaintenanceItemCard(item = item, onDone = { viewModel.markDone(item.id) })
                }
            }

            if (soonItems.isNotEmpty()) {
                item {
                    Text(
                        "🔔 곧 필요",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFE65100),
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                items(soonItems, key = { it.id }) { item ->
                    MaintenanceItemCard(item = item, onDone = { viewModel.markDone(item.id) })
                }
            }

            if (normalItems.isNotEmpty()) {
                item {
                    Text(
                        "✅ 정상",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF43A047),
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                items(normalItems, key = { it.id }) { item ->
                    MaintenanceItemCard(item = item, onDone = { viewModel.markDone(item.id) })
                }
            }

            if (items.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🏠", style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.height(8.dp))
                            Text("관리 항목을 추가해보세요", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    if (showAddDialog) {
        AddMaintenanceDialog(
            onConfirm = { title, cycle ->
                viewModel.addItem(title, cycle)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
fun MaintenanceItemCard(item: HomeMaintenanceItem, onDone: () -> Unit) {
    val now = System.currentTimeMillis()
    val status = item.status()
    val elapsed = item.lastDoneAt?.let { TimeUnit.MILLISECONDS.toDays(now - it) }
    val daysLeft = elapsed?.let { item.cycleDays - it }
    val sdf = SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN)

    val (badgeBg, badgeText, badgeLabel) = when (status) {
        MaintenanceStatus.OVERDUE -> Triple(
            Color(0xFFFFEBEE), Color(0xFFE53935),
            elapsed?.let { "+${it - item.cycleDays}일" } ?: "기록 없음"
        )
        MaintenanceStatus.SOON -> Triple(
            Color(0xFFFFF8E1), Color(0xFFE65100),
            "D-${daysLeft}"
        )
        MaintenanceStatus.NORMAL -> Triple(
            Color(0xFFE8F5E9), Color(0xFF43A047),
            "D-${daysLeft}"
        )
        MaintenanceStatus.UNRECORDED -> Triple(
            Color(0xFFF5F5F5), Color(0xFF757575),
            "미기록"
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "주기 ${item.cycleDays}일" +
                        (item.lastDoneAt?.let { " · 마지막 ${sdf.format(Date(it))}" } ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(12.dp))
            Surface(shape = RoundedCornerShape(8.dp), color = badgeBg) {
                Text(
                    badgeLabel,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = badgeText
                )
            }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = onDone,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("완료", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun AddMaintenanceDialog(
    onConfirm: (String, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var cycleDays by remember { mutableStateOf("30") }
    val presets = listOf(
        "정수기 필터" to 90, "에어컨 청소" to 365, "공기청정기 필터" to 90,
        "배수구 청소" to 30, "보일러 점검" to 365, "엔진오일" to 90
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("관리 항목 추가") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("항목 이름") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("빠른 선택", style = MaterialTheme.typography.labelMedium)
                presets.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (name, cycle) ->
                            SuggestionChip(
                                onClick = { title = name; cycleDays = cycle.toString() },
                                label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = cycleDays,
                    onValueChange = { cycleDays = it.filter { c -> c.isDigit() } },
                    label = { Text("권장 주기 (일)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val days = cycleDays.toIntOrNull() ?: 30
                    if (title.isNotBlank()) onConfirm(title.trim(), days)
                },
                enabled = title.isNotBlank()
            ) { Text("추가") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}
