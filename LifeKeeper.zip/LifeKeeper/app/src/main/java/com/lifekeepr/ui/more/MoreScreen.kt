package com.lifekeepr.ui.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

@Composable
fun MoreScreen() {
    Scaffold(
        topBar = { TopAppBar(title = { Text("더보기") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        MoreMenuItem(
                            icon = Icons.Default.Place,
                            title = "물건 위치 기억",
                            subtitle = "어디에 뒀는지 저장하기",
                            onClick = {}
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        MoreMenuItem(
                            icon = Icons.Default.LocalShipping,
                            title = "택배 / 주문 기억",
                            subtitle = "주문한 물건 상태 관리",
                            onClick = {}
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        MoreMenuItem(
                            icon = Icons.Default.CalendarMonth,
                            title = "가족 일정",
                            subtitle = "가족 생활 일정 관리",
                            onClick = {}
                        )
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        MoreMenuItem(
                            icon = Icons.Default.Search,
                            title = "통합 검색",
                            subtitle = "앱 전체에서 한 번에 검색",
                            onClick = {}
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        MoreMenuItem(
                            icon = Icons.Default.NotificationsActive,
                            title = "알림 설정",
                            subtitle = "알림 종류별 켜고 끄기",
                            onClick = {}
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        MoreMenuItem(
                            icon = Icons.Default.LocationOn,
                            title = "장소 알림 관리",
                            subtitle = "Geofence 장소 등록 및 관리",
                            onClick = {}
                        )
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        MoreMenuItem(
                            icon = Icons.Default.Backup,
                            title = "백업 / 복원",
                            subtitle = "데이터 내보내기 및 가져오기",
                            onClick = {}
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        MoreMenuItem(
                            icon = Icons.Default.Info,
                            title = "앱 정보",
                            subtitle = "버전 1.0.0",
                            onClick = {}
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MoreMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
