package com.lifekeepr.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.lifekeepr.data.local.dao.*
import com.lifekeepr.data.local.entity.*

@Database(
    entities = [
        ShoppingItem::class,
        GeofenceLocation::class,
        RecordItem::class,
        HomeMaintenanceItem::class,
        FamilyScheduleItem::class,
        StoredItemLocation::class,
        DeliveryItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun shoppingItemDao(): ShoppingItemDao
    abstract fun geofenceLocationDao(): GeofenceLocationDao
    abstract fun recordItemDao(): RecordItemDao
    abstract fun homeMaintenanceDao(): HomeMaintenanceDao
    abstract fun familyScheduleDao(): FamilyScheduleDao
    abstract fun storedItemLocationDao(): StoredItemLocationDao
    abstract fun deliveryItemDao(): DeliveryItemDao
}
