package com.lifekeepr

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LifeKeeperApp : Application()
