package com.lifekeepr.ui.theme

import androidx.compose.ui.graphics.Color

val Teal10  = Color(0xFF002019)
val Teal20  = Color(0xFF00382D)
val Teal40  = Color(0xFF00897B)
val Teal80  = Color(0xFF80CBC4)
val Teal90  = Color(0xFFB2DFDB)
val TealContainer = Color(0xFFE0F2F1)

val Amber40 = Color(0xFFFFB300)
val AmberContainer = Color(0xFFFFF8E1)

val Red40   = Color(0xFFE53935)
val RedContainer = Color(0xFFFFEBEE)

val Green40 = Color(0xFF43A047)
val GreenContainer = Color(0xFFE8F5E9)

val Neutral10 = Color(0xFF1A1D1E)
val Neutral20 = Color(0xFF2E3133)
val Neutral90 = Color(0xFFE1E3E4)
val Neutral95 = Color(0xFFF0F1F2)
val Neutral99 = Color(0xFFF9FAFB)
