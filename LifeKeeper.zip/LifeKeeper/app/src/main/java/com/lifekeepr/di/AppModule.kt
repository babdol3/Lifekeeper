package com.lifekeepr.di

import android.content.Context
import androidx.room.Room
import com.lifekeepr.data.local.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "lifekeeper.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides @Singleton fun provideShoppingDao(db: AppDatabase) = db.shoppingItemDao()
    @Provides @Singleton fun provideRecordDao(db: AppDatabase) = db.recordItemDao()
    @Provides @Singleton fun provideMaintenanceDao(db: AppDatabase) = db.homeMaintenanceDao()
    @Provides @Singleton fun provideGeofenceDao(db: AppDatabase) = db.geofenceLocationDao()
    @Provides @Singleton fun provideFamilyScheduleDao(db: AppDatabase) = db.familyScheduleDao()
    @Provides @Singleton fun provideStoredItemLocationDao(db: AppDatabase) = db.storedItemLocationDao()
    @Provides @Singleton fun provideDeliveryItemDao(db: AppDatabase) = db.deliveryItemDao()
}
