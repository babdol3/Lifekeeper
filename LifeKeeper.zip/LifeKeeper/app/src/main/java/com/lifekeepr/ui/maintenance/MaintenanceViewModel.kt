package com.lifekeepr.ui.maintenance

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lifekeepr.data.local.dao.HomeMaintenanceDao
import com.lifekeepr.data.local.entity.HomeMaintenanceItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MaintenanceViewModel @Inject constructor(
    private val dao: HomeMaintenanceDao
) : ViewModel() {

    val items = dao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addItem(title: String, cycleDays: Int) = viewModelScope.launch {
        dao.insert(HomeMaintenanceItem(title = title, cycleDays = cycleDays))
    }

    fun markDone(id: Long) = viewModelScope.launch {
        dao.recordDone(id, System.currentTimeMillis())
    }

    fun deleteItem(item: HomeMaintenanceItem) = viewModelScope.launch {
        dao.delete(item)
    }
}
