package com.lifekeepr.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lifekeepr.data.local.dao.*
import com.lifekeepr.data.local.entity.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

data class HomeUiState(
    val overdueMaintenanceItems: List<HomeMaintenanceItem> = emptyList(),
    val soonMaintenanceItems: List<HomeMaintenanceItem> = emptyList(),
    val overdueRecordItems: List<RecordItem> = emptyList(),
    val activeShoppingCount: Int = 0,
    val upcomingSchedules: List<FamilyScheduleItem> = emptyList(),
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val maintenanceDao: HomeMaintenanceDao,
    private val recordDao: RecordItemDao,
    private val shoppingDao: ShoppingItemDao,
    private val familyScheduleDao: FamilyScheduleDao,
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        maintenanceDao.getAll(),
        recordDao.getAll(),
        shoppingDao.getActiveCount(),
        familyScheduleDao.getUpcoming(System.currentTimeMillis())
    ) { maintenance, records, shoppingCount, schedules ->
        val now = System.currentTimeMillis()
        val overdueMaint = maintenance.filter { item ->
            val last = item.lastDoneAt ?: return@filter true
            now - last > TimeUnit.DAYS.toMillis(item.cycleDays.toLong())
        }
        val soonMaint = maintenance.filter { item ->
            val last = item.lastDoneAt ?: return@filter false
            val elapsed = TimeUnit.MILLISECONDS.toDays(now - last)
            val threshold = (item.cycleDays * 0.85).toLong()
            elapsed >= threshold && elapsed < item.cycleDays
        }
        HomeUiState(
            overdueMaintenanceItems = overdueMaint,
            soonMaintenanceItems = soonMaint,
            overdueRecordItems = records.filter { r ->
                val last = r.lastDoneAt ?: return@filter false
                val cycle = r.recommendedCycleDays ?: return@filter false
                now - last > TimeUnit.DAYS.toMillis(cycle.toLong())
            },
            activeShoppingCount = shoppingCount,
            upcomingSchedules = schedules.take(3)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())
}
