package com.lifekeepr.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String = "MART",
    val isCompleted: Boolean = false,
    val geofenceLocationId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "geofence_locations")
data class GeofenceLocation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Float = 300f,
    val isActive: Boolean = true,
    val lastAlertAt: Long? = null
)

@Entity(tableName = "record_items")
data class RecordItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val lastDoneAt: Long? = null,
    val recommendedCycleDays: Int? = null,
    val memo: String = ""
)

@Entity(tableName = "home_maintenance_items")
data class HomeMaintenanceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val lastDoneAt: Long? = null,
    val cycleDays: Int = 30,
    val memo: String = ""
)

@Entity(tableName = "family_schedule_items")
data class FamilyScheduleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val memberTag: String = "ME",
    val scheduledAt: Long,
    val memo: String = "",
    val isNotified: Boolean = false
)

@Entity(tableName = "stored_item_locations")
data class StoredItemLocation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemName: String,
    val location: String,
    val memo: String = "",
    val photoUri: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "delivery_items")
data class DeliveryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemName: String,
    val orderedAt: Long = System.currentTimeMillis(),
    val expectedAt: Long? = null,
    val status: String = "ORDERED",
    val memo: String = ""
)
