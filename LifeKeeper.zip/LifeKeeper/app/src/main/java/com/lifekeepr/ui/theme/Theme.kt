package com.lifekeepr.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = Teal40,
    onPrimary = Color.White,
    primaryContainer = TealContainer,
    onPrimaryContainer = Teal10,
    secondary = Amber40,
    onSecondary = Color.White,
    secondaryContainer = AmberContainer,
    background = Neutral99,
    surface = Color.White,
    surfaceVariant = Neutral95,
    onBackground = Neutral10,
    onSurface = Neutral10,
    onSurfaceVariant = Neutral20,
    error = Red40,
    errorContainer = RedContainer,
)

private val DarkColorScheme = darkColorScheme(
    primary = Teal80,
    onPrimary = Teal20,
    primaryContainer = Teal40,
    onPrimaryContainer = Teal90,
    secondary = Amber40,
    background = Neutral10,
    surface = Neutral20,
    surfaceVariant = Neutral20,
    onBackground = Neutral90,
    onSurface = Neutral90,
)

@Composable
fun LifeKeeperTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
