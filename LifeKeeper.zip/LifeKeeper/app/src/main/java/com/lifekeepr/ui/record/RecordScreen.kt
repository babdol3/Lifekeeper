package com.lifekeepr.ui.record

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lifekeepr.data.local.entity.RecordItem
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun RecordScreen(viewModel: RecordViewModel = hiltViewModel()) {
    val items by viewModel.items.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val overdueItems = items.filter { item ->
        val last = item.lastDoneAt ?: return@filter false
        val cycle = item.recommendedCycleDays ?: return@filter false
        now - last > TimeUnit.DAYS.toMillis(cycle.toLong())
    }
    val normalItems = items.filter { it !in overdueItems }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("마지막 언제였지?", style = MaterialTheme.typography.titleLarge)
                        Text("탭 한 번으로 오늘 기록", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("기록 추가") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (overdueItems.isNotEmpty()) {
                item {
                    Text(
                        "🔴 주기 초과",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFE53935),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                items(overdueItems, key = { it.id }) { item ->
                    RecordItemCard(item = item, onRecordToday = { viewModel.recordToday(item.id) })
                }
            }

            if (normalItems.isNotEmpty()) {
                item {
                    Text(
                        "✅ 기록 항목",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                items(normalItems, key = { it.id }) { item ->
                    RecordItemCard(item = item, onRecordToday = { viewModel.recordToday(item.id) })
                }
            }

            if (items.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("📅", style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.height(8.dp))
                            Text("기록할 항목을 추가해보세요", style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "예: 치과 방문, 엔진오일, 운동",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    if (showAddDialog) {
        AddRecordDialog(
            onConfirm = { title, cycle ->
                viewModel.addItem(title, cycle)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
fun RecordItemCard(item: RecordItem, onRecordToday: () -> Unit) {
    val now = System.currentTimeMillis()
    val sdf = SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN)
    val elapsed = item.lastDoneAt?.let { TimeUnit.MILLISECONDS.toDays(now - it) }
    val isOverdue = elapsed != null && item.recommendedCycleDays != null &&
        elapsed >= item.recommendedCycleDays

    val isToday = item.lastDoneAt?.let {
        val cal1 = Calendar.getInstance().apply { timeInMillis = it }
        val cal2 = Calendar.getInstance()
        cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
            cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
    } ?: false

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    item.lastDoneAt?.let { "마지막: ${sdf.format(Date(it))}" } ?: "아직 기록 없음",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                item.recommendedCycleDays?.let {
                    Text(
                        "권장 주기: ${it}일",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            if (isToday) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE8F5E9)
                ) {
                    Text(
                        "오늘 완료 ✓",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF43A047)
                    )
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    elapsed?.let {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isOverdue) Color(0xFFFFEBEE) else Color(0xFFF5F5F5)
                        ) {
                            Text(
                                "D+$it",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isOverdue) Color(0xFFE53935) else Color(0xFF757575)
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                    OutlinedButton(
                        onClick = onRecordToday,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("오늘 기록", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun AddRecordDialog(
    onConfirm: (String, Int?) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var cycleText by remember { mutableStateOf("") }
    val presets = listOf(
        "치과 방문" to 180, "엔진오일 교체" to 90, "에어컨 청소" to 365,
        "부모님 방문" to 14, "운동" to 2, "약 복용" to 1
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("기록 항목 추가") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("항목 이름 (예: 치과 방문)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("빠른 선택", style = MaterialTheme.typography.labelMedium)
                presets.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (name, cycle) ->
                            SuggestionChip(
                                onClick = { title = name; cycleText = cycle.toString() },
                                label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = cycleText,
                    onValueChange = { cycleText = it.filter { c -> c.isDigit() } },
                    label = { Text("권장 주기 (일, 비워도 됨)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) onConfirm(title.trim(), cycleText.toIntOrNull())
                },
                enabled = title.isNotBlank()
            ) { Text("추가") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}
