package com.lifekeepr.ui.shopping

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lifekeepr.data.local.entity.ShoppingItem

val categoryLabels = mapOf(
    "MART" to "마트",
    "DAISO" to "다이소",
    "PHARMACY" to "약국",
    "CONVENIENCE" to "편의점",
    "ONLINE" to "온라인",
    "ETC" to "기타"
)

val categoryColors = mapOf(
    "MART" to (Color(0xFFE3F2FD) to Color(0xFF1565C0)),
    "DAISO" to (Color(0xFFFFF8E1) to Color(0xFFE65100)),
    "PHARMACY" to (Color(0xFFFFEBEE) to Color(0xFFE53935)),
    "CONVENIENCE" to (Color(0xFFE8F5E9) to Color(0xFF2E7D32)),
    "ONLINE" to (Color(0xFFEDE7F6) to Color(0xFF4527A0)),
    "ETC" to (Color(0xFFF5F5F5) to Color(0xFF424242))
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShoppingScreen(viewModel: ShoppingViewModel = hiltViewModel()) {
    val items by viewModel.items.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredItems = if (selectedFilter == "ALL") items
    else items.filter { it.category == selectedFilter }

    val activeCount = items.count { !it.isCompleted }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("장보기 목록", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "미완료 ${activeCount}개",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.clearCompleted() }) {
                        Icon(Icons.Default.Done, contentDescription = "완료 항목 삭제")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("추가") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Category filter chips
            ScrollableTabRow(
                selectedTabIndex = listOf("ALL", "MART", "DAISO", "PHARMACY", "CONVENIENCE", "ONLINE", "ETC")
                    .indexOf(selectedFilter),
                edgePadding = 16.dp,
                divider = {},
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                listOf("ALL" to "전체").plus(categoryLabels.entries.map { it.key to it.value })
                    .forEach { (key, label) ->
                        Tab(
                            selected = selectedFilter == key,
                            onClick = { selectedFilter = key },
                            text = { Text(label, style = MaterialTheme.typography.labelMedium) }
                        )
                    }
            }

            if (filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🛒", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("살 것을 추가해보세요", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val pending = filteredItems.filter { !it.isCompleted }
                    val done = filteredItems.filter { it.isCompleted }

                    if (pending.isNotEmpty()) {
                        items(pending, key = { it.id }) { item ->
                            ShoppingItemCard(
                                item = item,
                                onToggle = { viewModel.toggleCompleted(item) },
                                onDelete = { viewModel.deleteItem(item) },
                                modifier = Modifier.animateItemPlacement()
                            )
                        }
                    }

                    if (done.isNotEmpty()) {
                        item {
                            Text(
                                "완료 (${done.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                            )
                        }
                        items(done, key = { it.id }) { item ->
                            ShoppingItemCard(
                                item = item,
                                onToggle = { viewModel.toggleCompleted(item) },
                                onDelete = { viewModel.deleteItem(item) },
                                modifier = Modifier.animateItemPlacement()
                            )
                        }
                    }

                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showAddDialog) {
        AddShoppingDialog(
            onConfirm = { name, category ->
                viewModel.addItem(name, category)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
fun ShoppingItemCard(
    item: ShoppingItem,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = categoryColors[item.category] ?: (Color(0xFFF5F5F5) to Color(0xFF424242))

    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(if (item.isCompleted) 0.dp else 1.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isCompleted)
                MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = item.isCompleted,
                onCheckedChange = { onToggle() }
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyLarge,
                textDecoration = if (item.isCompleted) TextDecoration.LineThrough else null,
                color = if (item.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = bgColor
            ) {
                Text(
                    text = categoryLabels[item.category] ?: item.category,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = textColor
                )
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "삭제",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun AddShoppingDialog(
    onConfirm: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("MART") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("항목 추가") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("물건 이름") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("카테고리", style = MaterialTheme.typography.labelMedium)
                categoryLabels.entries.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (key, label) ->
                            FilterChip(
                                selected = selectedCategory == key,
                                onClick = { selectedCategory = key },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (name.isNotBlank()) onConfirm(name.trim(), selectedCategory) },
                enabled = name.isNotBlank()
            ) { Text("추가") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("취소") }
        }
    )
}
