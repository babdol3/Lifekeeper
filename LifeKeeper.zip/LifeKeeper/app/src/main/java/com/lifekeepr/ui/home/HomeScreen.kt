package com.lifekeepr.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lifekeepr.data.local.entity.FamilyScheduleItem
import com.lifekeepr.data.local.entity.HomeMaintenanceItem
import com.lifekeepr.data.local.entity.RecordItem
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun HomeScreen(
    onNavigateShopping: () -> Unit = {},
    onNavigateMaintenance: () -> Unit = {},
    onNavigateRecord: () -> Unit = {},
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val colorScheme = MaterialTheme.colorScheme

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Gradient header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(colorScheme.primary, colorScheme.primaryContainer)
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Column {
                    val cal = Calendar.getInstance()
                    val dayNames = arrayOf("일", "월", "화", "수", "목", "금", "토")
                    val dayStr = "${cal.get(Calendar.MONTH) + 1}월 ${cal.get(Calendar.DAY_OF_MONTH)}일 (${dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]})"
                    Text(
                        text = dayStr,
                        color = colorScheme.onPrimary.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "안녕하세요 👋",
                        color = colorScheme.onPrimary,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    val urgentCount = state.overdueMaintenanceItems.size + state.overdueRecordItems.size
                    val subMsg = if (urgentCount > 0) "확인할 것이 ${urgentCount}가지 있어요" else "오늘 할 일 없어요 🎉"
                    Text(
                        text = subMsg,
                        color = colorScheme.onPrimary.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    // Summary chips
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryChip(
                            icon = Icons.Default.Warning,
                            count = state.overdueMaintenanceItems.size,
                            label = "관리 필요",
                            containerColor = Color(0xFFFFEBEE),
                            contentColor = Color(0xFFE53935),
                            onClick = onNavigateMaintenance
                        )
                        SummaryChip(
                            icon = Icons.Default.ShoppingCart,
                            count = state.activeShoppingCount,
                            label = "장보기",
                            containerColor = Color(0xFFFFF8E1),
                            contentColor = Color(0xFFE65100),
                            onClick = onNavigateShopping
                        )
                        SummaryChip(
                            icon = Icons.Default.DateRange,
                            count = state.overdueRecordItems.size,
                            label = "기록 필요",
                            containerColor = colorScheme.primaryContainer,
                            contentColor = colorScheme.primary,
                            onClick = onNavigateRecord
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }

        // Overdue maintenance
        if (state.overdueMaintenanceItems.isNotEmpty()) {
            item {
                HomeSectionCard(
                    title = "⚠️ 관리 필요",
                    titleColor = Color(0xFFE53935),
                    actionLabel = "전체 보기",
                    onAction = onNavigateMaintenance,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    state.overdueMaintenanceItems.forEach { item ->
                        MaintenanceOverdueRow(item)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Soon maintenance
        if (state.soonMaintenanceItems.isNotEmpty()) {
            item {
                HomeSectionCard(
                    title = "🔔 곧 필요",
                    titleColor = Color(0xFFE65100),
                    actionLabel = "전체 보기",
                    onAction = onNavigateMaintenance,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    state.soonMaintenanceItems.forEach { item ->
                        MaintenanceSoonRow(item)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Family schedules
        if (state.upcomingSchedules.isNotEmpty()) {
            item {
                HomeSectionCard(
                    title = "👨‍👩‍👧 가족 일정",
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    state.upcomingSchedules.forEach { schedule ->
                        FamilyScheduleRow(schedule)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Shopping reminder
        if (state.activeShoppingCount > 0) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clickable { onNavigateShopping() },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.ShoppingCart,
                            contentDescription = null,
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "장보기 목록",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color(0xFFE65100)
                            )
                            Text(
                                "살 것 ${state.activeShoppingCount}개 남아있어요",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF5D4037)
                            )
                        }
                        Icon(
                            Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFFE65100)
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Empty state
        if (state.overdueMaintenanceItems.isEmpty() &&
            state.overdueRecordItems.isEmpty() &&
            state.activeShoppingCount == 0 &&
            state.upcomingSchedules.isEmpty()
        ) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🎉", fontSize = 40.sp)
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "오늘은 모두 완료!",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "새로운 항목을 추가해보세요",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryChip(
    icon: ImageVector,
    count: Int,
    label: String,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(containerColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = count.toString(),
                color = contentColor,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp
            )
            Text(
                text = label,
                color = contentColor,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

@Composable
fun HomeSectionCard(
    title: String,
    titleColor: Color = MaterialTheme.colorScheme.primary,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(modifier = modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = titleColor)
                if (actionLabel != null && onAction != null) {
                    TextButton(onClick = onAction, contentPadding = PaddingValues(0.dp)) {
                        Text(actionLabel, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun MaintenanceOverdueRow(item: HomeMaintenanceItem) {
    val daysPassed = item.lastDoneAt?.let {
        TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - it)
    } ?: 0L
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(item.title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFFFFEBEE)
        ) {
            Text(
                "+${daysPassed - item.cycleDays}일 초과",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFE53935)
            )
        }
    }
}

@Composable
fun MaintenanceSoonRow(item: HomeMaintenanceItem) {
    val now = System.currentTimeMillis()
    val daysPassed = item.lastDoneAt?.let { TimeUnit.MILLISECONDS.toDays(now - it) } ?: 0L
    val daysLeft = item.cycleDays - daysPassed
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(item.title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFFFFF8E1)
        ) {
            Text(
                "D-$daysLeft",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFE65100)
            )
        }
    }
}

@Composable
fun FamilyScheduleRow(item: FamilyScheduleItem) {
    val sdf = SimpleDateFormat("M/d (E)", Locale.KOREAN)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.title, style = MaterialTheme.typography.bodyMedium)
            Text(
                "[${item.memberTag}]",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Text(
            sdf.format(Date(item.scheduledAt)),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
