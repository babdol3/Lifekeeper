package com.lifekeepr.ui.record

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lifekeepr.data.local.dao.RecordItemDao
import com.lifekeepr.data.local.entity.RecordItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RecordViewModel @Inject constructor(
    private val dao: RecordItemDao
) : ViewModel() {

    val items = dao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addItem(title: String, cycleDays: Int?) = viewModelScope.launch {
        dao.insert(RecordItem(title = title, recommendedCycleDays = cycleDays))
    }

    fun recordToday(id: Long) = viewModelScope.launch {
        dao.recordToday(id, System.currentTimeMillis())
    }

    fun deleteItem(item: RecordItem) = viewModelScope.launch {
        dao.delete(item)
    }
}
