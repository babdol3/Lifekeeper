package com.lifekeepr.data.local.dao

import androidx.room.*
import com.lifekeepr.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShoppingItemDao {
    @Query("SELECT * FROM shopping_items WHERE isCompleted = 0 ORDER BY createdAt DESC")
    fun getActiveItems(): Flow<List<ShoppingItem>>

    @Query("SELECT * FROM shopping_items ORDER BY createdAt DESC")
    fun getAllItems(): Flow<List<ShoppingItem>>

    @Query("SELECT COUNT(*) FROM shopping_items WHERE isCompleted = 0")
    fun getActiveCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ShoppingItem): Long

    @Update
    suspend fun update(item: ShoppingItem)

    @Query("UPDATE shopping_items SET isCompleted = 1 WHERE id = :id")
    suspend fun markCompleted(id: Long)

    @Query("UPDATE shopping_items SET isCompleted = 0 WHERE id = :id")
    suspend fun unmarkCompleted(id: Long)

    @Delete
    suspend fun delete(item: ShoppingItem)

    @Query("DELETE FROM shopping_items WHERE isCompleted = 1")
    suspend fun clearCompleted()
}

@Dao
interface GeofenceLocationDao {
    @Query("SELECT * FROM geofence_locations WHERE isActive = 1")
    fun getActiveLocations(): Flow<List<GeofenceLocation>>

    @Query("SELECT * FROM geofence_locations")
    fun getAllLocations(): Flow<List<GeofenceLocation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(location: GeofenceLocation): Long

    @Update
    suspend fun update(location: GeofenceLocation)

    @Delete
    suspend fun delete(location: GeofenceLocation)

    @Query("UPDATE geofence_locations SET lastAlertAt = :timestamp WHERE id = :id")
    suspend fun updateLastAlert(id: Long, timestamp: Long)
}

@Dao
interface RecordItemDao {
    @Query("SELECT * FROM record_items ORDER BY lastDoneAt ASC NULLS FIRST")
    fun getAll(): Flow<List<RecordItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: RecordItem): Long

    @Update
    suspend fun update(item: RecordItem)

    @Query("UPDATE record_items SET lastDoneAt = :timestamp WHERE id = :id")
    suspend fun recordToday(id: Long, timestamp: Long)

    @Delete
    suspend fun delete(item: RecordItem)
}

@Dao
interface HomeMaintenanceDao {
    @Query("SELECT * FROM home_maintenance_items ORDER BY lastDoneAt ASC NULLS FIRST")
    fun getAll(): Flow<List<HomeMaintenanceItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: HomeMaintenanceItem): Long

    @Update
    suspend fun update(item: HomeMaintenanceItem)

    @Query("UPDATE home_maintenance_items SET lastDoneAt = :timestamp WHERE id = :id")
    suspend fun recordDone(id: Long, timestamp: Long)

    @Delete
    suspend fun delete(item: HomeMaintenanceItem)
}

@Dao
interface FamilyScheduleDao {
    @Query("SELECT * FROM family_schedule_items WHERE scheduledAt >= :from ORDER BY scheduledAt ASC")
    fun getUpcoming(from: Long): Flow<List<FamilyScheduleItem>>

    @Query("SELECT * FROM family_schedule_items ORDER BY scheduledAt ASC")
    fun getAll(): Flow<List<FamilyScheduleItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: FamilyScheduleItem): Long

    @Update
    suspend fun update(item: FamilyScheduleItem)

    @Delete
    suspend fun delete(item: FamilyScheduleItem)
}

@Dao
interface StoredItemLocationDao {
    @Query("SELECT * FROM stored_item_locations ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<StoredItemLocation>>

    @Query("SELECT * FROM stored_item_locations WHERE itemName LIKE '%' || :query || '%' OR location LIKE '%' || :query || '%'")
    fun search(query: String): Flow<List<StoredItemLocation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: StoredItemLocation): Long

    @Update
    suspend fun update(item: StoredItemLocation)

    @Delete
    suspend fun delete(item: StoredItemLocation)
}

@Dao
interface DeliveryItemDao {
    @Query("SELECT * FROM delivery_items WHERE status != 'DELIVERED' ORDER BY orderedAt DESC")
    fun getActiveDeliveries(): Flow<List<DeliveryItem>>

    @Query("SELECT * FROM delivery_items ORDER BY orderedAt DESC")
    fun getAll(): Flow<List<DeliveryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: DeliveryItem): Long

    @Update
    suspend fun update(item: DeliveryItem)

    @Query("UPDATE delivery_items SET status = 'DELIVERED' WHERE id = :id")
    suspend fun markDelivered(id: Long)

    @Delete
    suspend fun delete(item: DeliveryItem)
}
