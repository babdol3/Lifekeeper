package com.lifekeepr.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.lifekeepr.ui.home.HomeScreen
import com.lifekeepr.ui.maintenance.MaintenanceScreen
import com.lifekeepr.ui.more.MoreScreen
import com.lifekeepr.ui.record.RecordScreen
import com.lifekeepr.ui.shopping.ShoppingScreen

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home        : Screen("home",        "홈",    Icons.Default.Home)
    object Shopping    : Screen("shopping",    "구매",   Icons.Default.ShoppingCart)
    object Record      : Screen("record",      "기록",   Icons.Default.DateRange)
    object Maintenance : Screen("maintenance", "집관리", Icons.Default.Build)
    object More        : Screen("more",        "더보기", Icons.Default.Menu)
}

val bottomNavItems = listOf(
    Screen.Home, Screen.Shopping, Screen.Record, Screen.Maintenance, Screen.More
)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDest = navBackStackEntry?.destination
                bottomNavItems.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        selected = currentDest?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateShopping = { navController.navigate(Screen.Shopping.route) },
                    onNavigateMaintenance = { navController.navigate(Screen.Maintenance.route) },
                    onNavigateRecord = { navController.navigate(Screen.Record.route) }
                )
            }
            composable(Screen.Shopping.route)    { ShoppingScreen() }
            composable(Screen.Record.route)      { RecordScreen() }
            composable(Screen.Maintenance.route) { MaintenanceScreen() }
            composable(Screen.More.route)        { MoreScreen() }
        }
    }
}
