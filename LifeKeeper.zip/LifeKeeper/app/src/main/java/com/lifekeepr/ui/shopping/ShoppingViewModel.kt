package com.lifekeepr.ui.shopping

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lifekeepr.data.local.dao.ShoppingItemDao
import com.lifekeepr.data.local.entity.ShoppingItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShoppingViewModel @Inject constructor(
    private val dao: ShoppingItemDao
) : ViewModel() {

    val items = dao.getAllItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addItem(name: String, category: String) = viewModelScope.launch {
        dao.insert(ShoppingItem(name = name, category = category))
    }

    fun toggleCompleted(item: ShoppingItem) = viewModelScope.launch {
        if (item.isCompleted) dao.unmarkCompleted(item.id)
        else dao.markCompleted(item.id)
    }

    fun deleteItem(item: ShoppingItem) = viewModelScope.launch {
        dao.delete(item)
    }

    fun clearCompleted() = viewModelScope.launch {
        dao.clearCompleted()
    }
}
