# 생활비서 (LifeKeeper)

사용자의 기억을 대신해주는 생활관리 Android 앱

## 빠른 빌드 (GitHub Codespaces)

### 1단계 - Codespace 열기
GitHub 레포 페이지 → **Code** → **Codespaces** → **Create codespace on main**

### 2단계 - 터미널에서 한 줄 실행
```bash
bash setup.sh
```
끝! 약 5~10분 후 APK 생성됩니다.

### 3단계 - APK 다운로드
좌측 파일 탐색기 → `app/build/outputs/apk/debug/app-debug.apk` → 우클릭 → Download

## 기능 (MVP v1.0)
- 🏠 홈 대시보드 - 오늘 필요한 정보 한눈에
- 🛒 장보기 목록 - 카테고리별 관리 + 체크
- 📅 마지막 언제였지? - 기록 추적
- 🏠 집 관리 - D-Day 주기 관리
- 📍 장소 기반 알림 - Geofence
