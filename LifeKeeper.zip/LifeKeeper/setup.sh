#!/bin/bash
set -e
echo "================================================"
echo "  생활비서 (LifeKeeper) - 빌드 자동 설정"
echo "================================================"

# 1. Java 17
echo "[1/5] Java 17 설치 중..."
sudo apt-get update -qq
sudo apt-get install -y -qq openjdk-17-jdk wget unzip
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
export PATH=$JAVA_HOME/bin:$PATH

# 2. Android SDK
echo "[2/5] Android SDK 설치 중..."
export ANDROID_HOME=$HOME/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools

cd $ANDROID_HOME/cmdline-tools
wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O tools.zip
unzip -q tools.zip
mv cmdline-tools latest
rm tools.zip

export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

# 3. SDK 라이선스 & 패키지
echo "[3/5] SDK 패키지 설치 중 (시간 걸릴 수 있어요)..."
yes | sdkmanager --licenses > /dev/null 2>&1
sdkmanager --quiet "platform-tools" "platforms;android-35" "build-tools;35.0.0"

# 4. local.properties 업데이트
echo "[4/5] 프로젝트 설정 중..."
cd /workspaces/LifeKeeper
echo "sdk.dir=$ANDROID_HOME" > local.properties

# 환경변수 영구 저장
echo "export ANDROID_HOME=$ANDROID_HOME" >> ~/.bashrc
echo "export JAVA_HOME=$JAVA_HOME" >> ~/.bashrc
echo "export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools" >> ~/.bashrc

# 5. 빌드
echo "[5/5] APK 빌드 중..."
chmod +x gradlew
./gradlew assembleDebug --no-daemon -q

echo ""
echo "================================================"
echo "  ✅ 빌드 완료!"
echo "  📦 APK 위치:"
echo "  app/build/outputs/apk/debug/app-debug.apk"
echo "================================================"
